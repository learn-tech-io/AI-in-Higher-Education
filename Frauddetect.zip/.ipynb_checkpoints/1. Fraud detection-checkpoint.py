import pandas as pd

data = pd.read_csv('fraud_data.csv')

subset = data[data['Fraud_reported'] == 'Yes']

print (subset.groupby(['Country_of_transaction'])['Fraud_reported'].count())












